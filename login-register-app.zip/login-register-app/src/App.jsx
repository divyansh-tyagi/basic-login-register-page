import React from 'react'
import { UserPage } from './components/UserPage';

export const App = () => {
  return (
    <UserPage/>
  )
}
export default App;