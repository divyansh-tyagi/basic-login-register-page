import React from 'react'

export const PasswordField = () => {
  return (
<div className="form-group">
        <label>Password</label>
        <input className=" form-control" type='password' placeholder='Type Password Here'/>
      </div>
        )
}
